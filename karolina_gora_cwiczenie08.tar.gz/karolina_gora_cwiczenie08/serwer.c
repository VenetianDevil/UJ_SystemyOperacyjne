#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>
//fork
#include <sys/types.h>
#include <unistd.h>
//exit
#include <stdlib.h>
//toupper
#include <ctype.h>
#include <errno.h>

#include "kolejki.h"

int main()
{
    key_t klucz = make_key();

    int msqid = make_queue(klucz);
    printf("Stworzylem kolejke\n");

//serwer start
    printf("Serwer stworzony\n");

    //pobranie komunikatu z kolejki
    struct msgbuf odebrane;
    int lenght, i;
    long lokacja;

    if(signal(SIGINT, sighandler) == SIG_ERR)
    {
	perror("signal error");
	exit(10);
    }

    while(1)
    {
	//lenght = receive(msqid, odebrane, 1);
	lenght = msgrcv(msqid, &odebrane, 256, 1, 0);
	if(lenght == -1)
	{
	    perror("msgrcv serwer error");
	    exit(7);
	}

        lokacja = odebrane.stype;

	printf("Serwer: odebralem od klienta: %s\n", odebrane.mtext);
	for(i=0; i<lenght; i++)
	{
	    odebrane.mtext[i] = toupper(odebrane.mtext[i]);
	}
	odebrane.mtype = lokacja;
	
//wysalanie zmienionego komunikatu do kolejki

	send(msqid, odebrane, lenght);
	printf("Serwer: wyslalem do klienta: %s\n", odebrane.mtext);
    }
//serwer koniec
    return 0;
}