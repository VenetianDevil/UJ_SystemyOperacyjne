#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <errno.h>
#include <signal.h>
#include "kolejki.h"

key_t make_key()
{
    key_t klucz = ftok("main.c", 3);
    if(klucz == -1)
    {
        perror("ftok error");
        exit(3);
    }
    return klucz;
}

int make_queue(key_t klucz)
{
    int msqid = msgget(klucz, IPC_CREAT|0666);
    if(msqid == -1)
    {
        perror("msgget msqid error");
        exit(2);
    }
    return msqid;
}

void remove_queue(int msqid)
{
    if(msgctl(msqid, IPC_RMID, NULL)==-1)
    {
        perror("msqctl remove error");
        exit(1);
    }
}

int receive(int msqid, struct msgbuf odebrane, long mtype)
{
    int lenght = msgrcv(msqid, &odebrane, 256, mtype, 0);
    if(lenght == -1)
    {
	perror("msgrcv error");
	exit(7);
    }
    return lenght;
}

void send(int msqid, struct msgbuf wiadomosc, int lenght)
{
    if(msgsnd(msqid, &wiadomosc, lenght, 0)==-1)
    {
	perror("msgsnd error");
	exit(11);
    }
}

void sighandler(int x)
{
    key_t klucz = make_key();
    int msqid = make_queue(klucz);
    remove_queue(msqid);
    printf("\nkolejka usunieta\n");
    exit(EXIT_SUCCESS);
}