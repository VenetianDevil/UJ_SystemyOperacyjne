#ifndef KOL_H
#define KOL_H

key_t make_key();

int make_queue(key_t);

void remove_queue(int);

void sighandler (int);

struct msgbuf
{
    long mtype; //typ komunikatu
    long stype;
    char mtext[20]; //tekst komunikatu
};

int receive(int, struct msgbuf, long);

void send(int, struct msgbuf, int);

#endif