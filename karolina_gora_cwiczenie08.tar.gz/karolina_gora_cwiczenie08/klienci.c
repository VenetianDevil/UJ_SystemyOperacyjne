#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include "kolejki.h"
#include <stdlib.h>
#include <unistd.h>
#include <string.h>


int main(int argc, char *argv[])
{
    key_t klucz = make_key();
    int msqid = make_queue(klucz);

    printf("Klient stworzony\n");

    struct msgbuf tekst;
    tekst.mtype = 1;

    long lokacja = (long)getpid();
    tekst.stype = lokacja;

    strcpy(tekst.mtext, argv[1]);
    int lenght=sizeof(tekst.mtext);//(ciag);

    //wyslanie komunikatu do kolejki

    send(msqid, tekst, lenght);
    printf("Klient: wyslalem do serwera: %s\n", tekst.mtext);

    struct msgbuf nowe;
    sleep(2);

    //odebranie zmienionego komunikatu z kolejki
    //receive(msqid, nowe, lokacja);

    if(msgrcv(msqid, &nowe, 256, lokacja, 0)==-1)
    {
        perror("msgrcv klient error");
        exit(9);
    }

    printf("Klient: odebralem od serwera: %s\n", nowe.mtext);
    //kod do podawania ciagu znakow

    return 0;
}