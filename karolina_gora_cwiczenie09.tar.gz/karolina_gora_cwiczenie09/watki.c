#define _REENTRANT //POSIX
#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int LICZNIK = 0;
pthread_mutex_t myMutex = PTHREAD_MUTEX_INITIALIZER; //inicjowanie muteksu jako otwartego

void* dzialanie()
{
    int licznik;
    int i;
    
    printf("-----Otwieram watek-----\n");
    sleep(1);

    //sekcja krytyczna
    for(i=0; i<2; i++)
    {
        if(pthread_mutex_lock(&myMutex)!=0)
        {
            perror("mutex lock error");
            exit(EXIT_FAILURE);
        }
        sleep(1);
        printf("\033[7;0H\033[2K");//ustawienie kursora
        printf("Blokuje watek\n");

        licznik = LICZNIK;
        licznik++;
        sleep(1);
        printf("\033[7;50H");//ustawienie kursora
        printf("Wartosc = %d\n", licznik);

        sleep(2);
        LICZNIK = licznik;

        printf("\033[7;50H");//ustawienie kursora
        printf("Koniec sekcji krytyczniej\n");
        sleep(1);

        if(pthread_mutex_unlock(&myMutex)!=0)
        {
            perror("mutex unlock error");
            exit(EXIT_FAILURE);
        }

        printf("\033[7;0H\033[2K");//ustawienie kursora
        printf("Odblokowuje watek\n");
    }
    pthread_exit(NULL);
}

int main()
{
    static int rzeczywista;
    int i;
    int ile=2;
    //tworze 2 watki
    pthread_t pthreadID[ile];
    printf("Tworze watki\n\n");
    for(i=0;i<ile;i++)
    {
        if(pthread_create(&pthreadID[i], NULL,(void*(*)())dzialanie, (void*)&rzeczywista)!=0)
        {
            perror("create error");
            exit(EXIT_FAILURE);
        }
    }

    //czekanie na zakonczenie tych watkow
    for(i=0;i<ile;i++)
    {
        if(pthread_join(pthreadID[i], NULL)!=0)
        {
            perror("join error");
            exit(EXIT_FAILURE);
        }
    }

    sleep(1);
    printf("Watki zakonczone\n");
    printf("Koncowa wartosc licznika to %d\n", LICZNIK);

    return 0;
}