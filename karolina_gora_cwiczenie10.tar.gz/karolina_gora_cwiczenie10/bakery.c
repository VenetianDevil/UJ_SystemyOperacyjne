#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

#define TRUE 1
#define FALSE 0

int ile = 2; //ilosc watkow/procesow
int LICZNIK = 0;
int num_proc[100]; //numery procesow
int wybor_proc[100]; // wybor procesu o numerze

int max(int num_proc[100])
{
    int i = 0;
    int max = num_proc[0];
    //znalezienie najwiekszego numeru z num_proc[]
    for(i=0; i<ile; i++)
    {
        if(max < num_proc[0])
        {
            max = num_proc[i];
        }
    }
    return max; //zwrocenie najwiekszego numeru
}

void lock_thread(int i)
{
    int j;
    wybor_proc[i] = TRUE;
    num_proc[i]=max(num_proc)+1;
    wybor_proc[i] = FALSE;
    for(j=0; j<ile; j++)
    {
        while(wybor_proc[j])
        while(num_proc[j]!=0 && (num_proc[j]<num_proc[i] || ((num_proc[i] == num_proc[j]) && j<i))){}
    }
}

void unlock_thread(int i)
{
    num_proc[i]=0;
}

void *dzialanie(void *dana)
{
    int watek = (intptr_t)dana; // rzutowanie na int przez intptr_t bo jest za dluga dana
    int licznik;
    
    lock_thread(watek); //blokuje watek
    printf("\033[2;0H\033[2K");
    printf("Proces %d\n", watek);
    sleep(1);
    printf("\033[3;0H\033[2K");//ustawienie kursora
    printf("Blokuje watek\n");
    
    licznik = LICZNIK;
    licznik++;
    sleep(1);
    printf("\033[3;50H");//ustawienie kursora
    printf("Wartosc = %d\n", licznik);
    
    sleep(2);
    LICZNIK = licznik;
    printf("\033[3;50H");//ustawienie kursora
    printf("Koniec sekcji krytyczniej\n");
    
    sleep(1);
    unlock_thread(watek); //odblokowuje watek    
    printf("\033[3;0H\033[2K");//ustawienie kursora
    printf("Odblokowuje watek\n");

    pthread_exit(NULL);
}

int main()
{
    //tworze watki
    pthread_t threadID[ile];
    static int i;
    for(i=0; i<ile; i++)
    {
        pthread_create(&threadID[i], NULL, (void*(*)()) dzialanie, (void *)i);
        pthread_join(threadID[i], NULL);
    }

    printf("Procesy zakonczone\n");
    printf("Wartosc licznika %d\n", LICZNIK);
    return 0;
}