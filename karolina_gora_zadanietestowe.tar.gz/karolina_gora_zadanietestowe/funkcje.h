#ifndef PROG1
#define PROG1

double pierwkwNewtona(double x, double przyblizenie);

#endif