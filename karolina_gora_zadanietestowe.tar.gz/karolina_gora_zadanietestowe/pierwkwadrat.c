#include "funkcje.h"
#include <math.h>

double pierwkwNewtona(double x, double przyblizenie)
{
	double a = x; //wartosc boku kwadratu
	//x=a*(x/a) - x pole kwadratu
	while (fabs(a-(x/a))>przyblizenie) //fabs() - wartosc bezwzgledna
	{
		a=(a+(x/a))/2;
	}
	return a;
}