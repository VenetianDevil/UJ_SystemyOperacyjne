#include <stdio.h>
#include "funkcje.h"

int main()
{
	printf("Podaj liczbe dodatnia do obliczenia pierwiastka kwadratowego: ");
	double x;
	scanf("%lf", &x);
	printf("Pierwiastek z x wynosi %.1lf\n", pierwkwNewtona(x, 0.01));
	return 0;
}