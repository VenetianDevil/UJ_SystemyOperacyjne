#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>
#include "semafory.h"

int main(int argc, char *argv[])
{
    int iloscprocesow = atoi(argv[1]);

    if(iloscprocesow < 2)
    {
        printf("Za mala ilosc procesow\n");
        exit(1);
    }

    key_t klucz = make_key();
    //printf("G klucz = %d\n", klucz);


    int semid = semaphore(klucz);

    //printf("G Semid = %d\n", semid);
    //sleep(1);

    //inicjacja wartosci semafora
    initiation(semid);

    int i;
    for(i=0; i<iloscprocesow; i++)
    {
        switch(fork())
        {
            case -1:
                perror("fork error\n");
                exit(1);
            break;

            case 0:
                printf("uruchamiam potomny: %d\n", getpid());
                if(execl("./potomny.x", "potomny.x", NULL))
                {
                    perror("execl error\n");
                    exit(2);
                }
            break;

            default:
            //if(i==iloscprocesow-1)
            //wait(0);
            break;
        }
    }

    //usuniecie zbioru semaforow
    remove_semaphore(semid);
    //printf("Semafor zostal usuniety\n");

    return 0;
}