#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include "semafory.h"
#include <stdlib.h>
#include <errno.h>

int main()
{
    key_t klucz = make_key();

    int semid = semaphore(klucz);

    //printf("%d klucz = %d\n", getpid(), klucz);
    //printf("%d Semid = %d\n", getpid(), semid);
    
    printf("%d probuje oposcic semafor\n", getpid());

    sleep(1);
    //opuszczenie semafora
    semaphore_down(semid);

    printf("%d zaczyna sekcje krytyczna\n", getpid());

    sleep(5);

    printf("%d konczy sekcje krytyczna\n", getpid());

    //printf("%d 2Semid = %d\n", getpid(), semid);
    

    //ile zostalo w kolejce

    sleep(1);
    int ilosc = left_processes(semid);

    printf("W kolejce zostalo %d procesow.\n\n", ilosc);

    //podniesienie semafora
    semaphore_up(semid);

    sleep(2);
    return 0;
}