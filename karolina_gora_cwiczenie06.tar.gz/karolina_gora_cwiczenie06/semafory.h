#ifndef SEM_H
#define SEM_H

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

//tworzenie klucza
key_t make_key();

int semaphore(key_t);

void initiation(int);

void remove_semaphore(int);

void semaphore_down(int);

int left_processes(int);

void semaphore_up(int);


#endif