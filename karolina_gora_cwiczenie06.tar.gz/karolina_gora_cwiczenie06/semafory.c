#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>

#ifdef _SEM_SEMUN_UNDEFINED
union semun
{
    int val; //wartosc dla SETVAL
    struct semid_ds *buf; //bufor dla IPC_STAT, IPC_SET
    unsigned short *array; //tablica dla GETALL, SETALL
    struct seminfo *__buf; //bufor dla IPC_INFO (secyfikacja linuksa)
};
#endif

//tworzenie klucza
key_t make_key()
{
    key_t klucz = ftok("./main.c", 2); //stworzenie klucza

    return klucz;
}

//stworzenie semafora /dostep do niego
int semaphore(key_t klucz)
{
    int semid = semget(klucz, 1, IPC_CREAT|0666); 
    if(semid == -1)
    {
        perror("2semget error");
        exit(1);
    }

    return semid;
}

//inicjacja wartosci semafora
void initiation(int semid)
{
    union semun inicjacja;
    inicjacja.val = 1;
    if(semctl(semid, 0, SETVAL, inicjacja)==-1)
    {
        perror("smctl error");
        exit(1);
    }
}

//usuniecie zbioru semaforow
void remove_semaphore(int semid)
{
    int val=0;
    //znaczy ze semafor jest opuszczony i wykorzystywany

    //odczytuje wartosc semafora co 5 sec az bedzie =1
    while (val==0)
    {
        sleep(5);
        val = semctl(semid, 0, GETVAL);
        if(val == -1)
        {
            perror("getval error");
            exit(1);
        }
    }

    //printf("val = %d", val);
    //czeka az wartosc semafora bedzie =1 zeby go usunac
    if(semctl(semid, 0, IPC_RMID)==-1)
    {
        perror("semtcl usun error");
        exit(1);
    }
    printf("Semafor zostal usuniety\n");
}

//opusczenie semafora
void semaphore_down(int semid)
{
    struct sembuf sop = {0, -1, 0};
    if(semop(semid, &sop, 1)==-1)
    {
        perror("2semop error");
        exit(1);
    }
}

//ile procesow czeka na podniesienie semafora
int left_processes(int semid)
{
    int ilosc = semctl(semid, 0, GETNCNT);
    if(ilosc == -1)
    {
        perror("ilosc error");
        exit(1);
    }
    return ilosc;
}

//podniesienie semafora
void semaphore_up(int semid)
{
    struct sembuf pod = {0, 1, 0};
    if(semop(semid, &pod, 1)==-1)
    {
        perror("3semop error");
        printf("error = %d", errno);
        exit(1);
    }
}