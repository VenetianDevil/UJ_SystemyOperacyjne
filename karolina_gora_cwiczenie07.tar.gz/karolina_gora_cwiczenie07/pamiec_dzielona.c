#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include "pamiec_dzielona.h"

int shared_memory(key_t klucz, size_t size)
{
    int shmid = shmget(klucz, size, IPC_CREAT|0666);
    if(shmid==-1)
    {
        perror("Shmget create error");
        exit(1);
    }
    return shmid;
}

//up-date struct shmid_ds
//NULL - system sam wybiera odpowiedni adres dowiazania
bufor* linkSM(int shmid)
{
    bufor* buf;
    buf = shmat(shmid, NULL, 0);
    if( buf == (bufor*)(-1))
    {
        perror ("shmat link error");
        exit(1);
    }
    return buf;
}

void remove_linkSM(bufor* buf)
{
    if(shmdt(buf)==-1)
    {
        perror("shmdt remove link error");
        exit(1);
    }

    printf("Dowiazanie do pamieci usuniete.\n");
}

void remove_shared_memory(int shmid, bufor* buf)
{
    if(shmctl(shmid, IPC_RMID, (struct shmid_ds*)buf)==-1)
    {
        perror("shmctl remove error");
        exit(1);
    }

    printf("Segment pamieci usuniety.\n");
}
