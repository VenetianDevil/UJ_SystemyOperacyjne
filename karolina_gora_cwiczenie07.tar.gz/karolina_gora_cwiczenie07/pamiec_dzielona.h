#ifndef PD_H
#define PD_H

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct
{
    char dana;
} bufor;

int shared_memory(key_t, size_t);

bufor* linkSM(int);

void remove_linkSM(bufor*);

void remove_shared_memory(int, bufor*);

#endif