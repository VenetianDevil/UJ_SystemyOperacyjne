#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include "semafory.h"
#include "pamiec_dzielona.h"

#define BUF_SIZE 5

int main()
{
    //uzyskanie dostepu do pamieci dzielonej
    key_t klucz = make_key();
    int shmid = shared_memory(klucz, BUF_SIZE);
    printf("Producent - Dostep do segmentu pamieci uzyskany.\n");

    //dowiazanie bufora do pamieci
    bufor *buf;
    buf = linkSM(shmid);

    //dostep do semafora
    int semid = semaphores(klucz, 2);

    //otwieram plik o odczytu
    FILE *surowce;
    surowce = fopen("./surowce", "r");
    int in = 0;
    char wartosc;

    do
    {
        semaphore_down(semid, 0); //semafor producenta 0
        printf("opuszczam semafor producenta\t");

        wartosc = fgetc(surowce);
        buf[in].dana = wartosc; //wstawienie danej do bufora
        printf("pobralem - %c", wartosc);

        in = (in + 1) % BUF_SIZE; //ustawienie pozycji ufora o 1 dalej, lub powrot na poczatek jak osiagna limit
        sleep(1);

        semaphore_up(semid, 1); //semafor konsumenta 1
        printf("\npodnosze semafor konsumenta\n");
    } 
    while(wartosc != EOF); //koniec gdy wartosc jest koncem pliku

    fclose(surowce);
    return 0;
}