#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include "semafory.h"
#include "pamiec_dzielona.h"

#define BUF_SIZE 5

int main()
{
    //uzyskanie dostepu do pamieci dzielonej
    key_t klucz = make_key();
    int shmid = shared_memory(klucz, BUF_SIZE);
    printf("Konsument - Dostep do segmentu pamieci uzyskany.\n");

    
    //dowiazanie bufora do pamieci
    bufor *buf;
    buf = linkSM(shmid);

    //dostep do semafora
    int semid = semaphores(klucz, 2);

    //otwieram plik do zapisu
    FILE *towar;
    towar = fopen("./towar", "w");
    int out = 0;
    char wartosc;

    do
    {
        semaphore_down(semid, 1); //semafor konsumenta 1
        printf("opuszczam semafor konsumenta\t");
        sleep(1);
        
        wartosc = buf[out].dana;
        
        if(wartosc != EOF) //jesli nie jest to koniec pliku
        {
            fputc (wartosc, towar); //zapisanie danej z bufora do pliku
            printf("przepisalem: %c", wartosc);
        }

        out = (out + 1) % BUF_SIZE; //ustawienie pozycju bufora o 1 dalej, lub powrot na poczatek jak osiagna limit
        
        semaphore_up(semid, 0); //semafor producenta 0
        printf("\npodnosze semafor producenta\n");       
    }
    while(wartosc != EOF);

    fclose(towar);
    return 0;
}