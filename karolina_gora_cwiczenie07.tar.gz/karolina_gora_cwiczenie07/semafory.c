#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>

#ifdef _SEM_SEMUN_UNDEFINED
union semun
{
    int val; //wartosc dla SETVAL
    struct semid_ds *buf; //bufor dla IPC_STAT, IPC_SET
    unsigned short *array; //tablica dla GETALL, SETALL
    struct seminfo *__buf; //bufor dla IPC_INFO (secyfikacja linuksa)
};
#endif

//tworzenie klucza
key_t make_key()
{
    key_t klucz = ftok("./pamiec_dzielona.c", 2); //stworzenie klucza

    return klucz;
}

//stworzenie semafora /dostep do niego
/*int semaphore(key_t klucz)
{
    int semid = semaphores(klucz, 1); 
    return semid;
}*/

int semaphores(key_t klucz, int count)
{
    int semid = semget(klucz, count, IPC_CREAT|0666); 
    if(semid == -1)
    {
        perror("2semget error");
        exit(1);
    }

    return semid;
}


//inicjacja wartosci semafora
void initiation(int semid, int count)
{
    int i;
    for(i=0;i<count;i++)
    {
        union semun inicjacja;
        inicjacja.val = 1;
        if(semctl(semid, i, SETVAL, inicjacja)==-1)
        {
            perror("smctl initiation error");
            exit(1);
        }
    }
}

//usuniecie zbioru semaforow
void remove_semaphore(int semid, int count)
{
    int val0=0;
    int val1=0;
    //znaczy ze semafor jest opuszczony i wykorzystywany

    //odczytuje wartosc semafora co 5 sec az bedzie =1
    while (val0==0 || val1 == 0)
    {
        sleep(2);
        val0 = semctl(semid, 0, GETVAL);
        val1 = semctl(semid, 1, GETVAL);
        //printf("val0 = %d\tval1 = %d\n", val0, val1);   
        if(val0 == -1 || val1 == -1)
        {
            perror("getval error");
            exit(1);
        }
    }

    //argument semnum jest ignorowany dla kodu IPC_RMID, usuwa caly zbior;
    if(semctl(semid, 32, IPC_RMID)==-1)
        {
            perror("semctl remove error");
            exit(1);
        }

    printf("Semafory zostaly usuniete\n");
}

//opusczenie semafora
void semaphore_down(int semid, int no)
{
    struct sembuf sop = {no, -1, 0};
    if(semop(semid, &sop, 1)==-1)
    {
        printf("opuszczanie nr = %d\n", no);
        perror("semop down error");
        exit(1);
    }
}

//podniesienie semafora
void semaphore_up(int semid, int no)
{
    struct sembuf pod = {no, 1, 0};
    if(semop(semid, &pod, 1)==-1)
    {
        perror("semop up error");
        printf("error = %d", errno);
        exit(1);
    }
}