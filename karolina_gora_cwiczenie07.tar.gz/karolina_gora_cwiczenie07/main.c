#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#include "semafory.h"
#include "pamiec_dzielona.h"

#define BUF_SIZE 5

int main()
{
    bufor *buf;

    //tworze klucz i segment
    key_t klucz = make_key();
    int shmid = shared_memory(klucz, BUF_SIZE);
    printf("Segment pamieci stworzony.\n");

    //dowiazanie pamieci dzielonej do przestrzeni danych
    buf = linkSM(shmid);
     printf("Bufor podlaczony do pamieci.\n");

    //tworze semafor i go inicjuje wart. 1
    int semid = semaphores(klucz, 2);
    initiation(semid, 2);

    //wywolanie potomnego procesu - producenta
    switch(fork())
    {
        case -1:
            perror("fork error");
            exit(1);
        break;

        case 0:
            if(execl("./producent.x", "producent.x", NULL)==-1)
            {
                perror("1execl error");
                exit(1);
            }
        break;
        default:
            //wywolanie potomnego procesu - konsumenta
            switch(fork())
            {
                case -1:
                    perror("fork error");
                    exit(1);
                break;

                case 0:
                    if(execl("./konsument.x", "konsument.x", NULL)==-1)
                    {
                        perror("execl error");
                        exit(1);
                    }
                break;
            }
        break;
    }

    //usuwam semafory
    remove_semaphore(semid, 2);

    //usuwam dowiazanie do segmentu
    remove_linkSM(buf);

    //usuwam segment pamieci
    remove_shared_memory(shmid, buf);

    return 0;
}