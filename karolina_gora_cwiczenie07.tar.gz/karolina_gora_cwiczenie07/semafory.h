#ifndef SEM_H
#define SEM_H

#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>

//tworzenie klucza
key_t make_key();

//int semaphore(key_t);

int semaphores(key_t, int);

void initiation(int, int);

void remove_semaphore(int, int);

void semaphore_down(int, int);

void semaphore_up(int, int);

#endif