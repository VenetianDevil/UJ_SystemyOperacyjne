#include <stdio.h>
#include "sygnaly.h"

void sighandler_custom (int x) //wypisanie nazwy przechwyconego sygnalu
{
    printf("\nReceived signal: %s\n", sys_siglist[x]);
}

int main(int argc, char *argv[]) // 3 argumenty
{       
    if(argc!=3)
    {
        printf("Wrong number of arguments\n");
        exit(1);
    }
    
    //printf("jestem w main.x\n");
    //printf("przekazane dane:\n%s\n%s\n%s\n", argv[0], argv[1], argv[2]);
    int sig=atol(argv[2]); // zamiana string na int
    int option=atol(argv[1]);
    int pid = getpid();
    printf ("PID: %d\n", pid);

    /*int PGID=getpgid(0);
    printf("PGID = %d\n", PGID);*/
    
    //printf("signal: %d\noption: %d\n", sig, option);

    switch(option)
    {
        case 1: // wykonanie operacji domyslnej sygnalu
            if(signal(sig, SIG_DFL) == SIG_ERR)
            {
                perror("error with signal\n");
                exit(EXIT_FAILURE);
            }
        break;

        case 2: // zignorowanie sygnalu
            if(signal(sig, SIG_IGN) == SIG_ERR)
            {
                perror("error with signal\n");
                exit(EXIT_FAILURE);
            }
        break;
        
        case 3: //przechwycenie sygnalu
            if(signal(sig, sighandler_custom) == SIG_ERR)
            {
                perror("error with signal\n");
                exit(EXIT_FAILURE);
            }
        break;

        default:
            printf("Error option number\n");
            exit(0);
        break;
    }
    while(1)
    {
        pause();
    }

    printf("KONIEC\n");
}
