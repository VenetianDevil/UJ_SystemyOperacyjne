#include <stdio.h>
#include "sygnaly.h"
#include <errno.h>

int main(int argc, char *argv[])
{
     if(argc!=3)
    {
        printf("Wrong number of arguments\n");
        exit(1);
    }

    int PGID=getpgid(0);
    printf("\nPGID = %d\n\n", PGID);
    
    int sig=atol(argv[2]);
    int i=0, pid=0;

    // ignorowanie przez proces macierzysty sygnalu wysylanego do grupy
    if(signal(sig, SIG_IGN) == SIG_ERR)
        {
            perror("error with signal\n");
            exit(EXIT_FAILURE);
        }

    for(i=0; i<3; i++)
    {    
        switch(pid=fork())
        {
            case -1:
                perror("fork error");
                exit(1);
            break;

            case 0: //potomny
                kill (getpid(), 0); // sprawdzenie istnienia procesu
                if(errno == ESRCH)
                    printf("No such process!\n");
                else
                {   
                    printf("Process exists\n");
                    if(execl("./sygnalya.x", argv[0], argv[1], argv[2], NULL)==-1)
                    {
                        perror("execl error\n");
                        exit(2);
                    }
                }
            break;

            default: //macierzysty
                if(i==2) wait(0);
            break;
        }
    }
    return 0;
}