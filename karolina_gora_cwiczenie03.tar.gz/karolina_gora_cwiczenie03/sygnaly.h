#ifndef SIG
#define SIG

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>

pid_t wait();
pid_t fork();
pid_t getpid();
pid_t getpgid();

unsigned sleep(unsigned sec);
int kill(pid_t pid, int sig); //definicja kill

#endif