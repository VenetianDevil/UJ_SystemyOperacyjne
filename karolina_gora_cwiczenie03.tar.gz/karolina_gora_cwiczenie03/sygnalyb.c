#include <stdio.h>
#include "sygnaly.h"
#include <errno.h>

int main(int argc, char *argv[])
{
     if(argc!=3)
    {
        printf("Wrong number of arguments\n");
        exit(1);
    }

    int sygnal = atol(argv[2]);
    int pid=0;
    switch(pid = fork())
    {
        case -1:
            perror("fork error");
            exit(1);
        break;

        case 0: //potomny
            kill (getpid(), 0); //sprawdzenie istnienia procesu
            if(errno == ESRCH)
                {
                    printf("No such process!\n");
                    exit(1);
                }
            else
            {
                printf("Process exists\n");
                if(execl("./sygnalya.x", argv[0], argv[1], argv[2], NULL)==-1)
                {
                    perror("execl error\n");
                    exit(2);
                }
            }
        break;

        default: //macierzysty
            sleep (1);
            kill(pid, sygnal); 
            wait(0);
        break;
    }
    return 0;
}