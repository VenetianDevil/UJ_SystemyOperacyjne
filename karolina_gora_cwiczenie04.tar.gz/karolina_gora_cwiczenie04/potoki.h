#ifndef PIPE_H
#define PIPE_H

#include <stdio.h>
#include <limits.h> //do nbyte
#include <sys/param.h> //do nbyte
#include <unistd.h> // write, read, close, unlink, pipe
//do open (deskryptor):
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

ssize_t write (int filedes, const void *buf, size_t nbyte); //funkcja zwaca liczbe rzeczywiscie zapisanych bajtow
ssize_t read (int filedes, void *buf, size_t nbyte);// zwraca 0 gdy dojdzie do konca pliku
//int open (const char *path, int flags, mode_t mode); //otwiera plik i zwraca jego deskryptor
int close (int filedes); // zamyka plik, zwalnia uzywany przez niego deskryptor
int unlink (const char *path);//usuwa dowiazanie do pliku, zmniejsza o 1 licznik dowiazan, gdy przyjmie 0 - plik zostanie usuniety

pid_t wait();
pid_t fork();
int pipe (int filedes[2]);// zwraca 2 deskryptory plikow, do dwoch strumieni danych
//filedes[1] - do zapisu, filedes[0] - do odczytu 

#endif