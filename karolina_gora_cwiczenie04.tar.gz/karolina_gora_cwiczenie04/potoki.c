#include <stdio.h>
#include "potoki.h"

int main()
{
    int filedes[2];
    char buf;

    if(pipe(filedes)==-1)
    {
        perror("Pipe error\n");
        exit(EXIT_FAILURE);
    }

    switch(fork())
    {
        case -1:
            perror("Fork error");
            exit(EXIT_FAILURE);
        break;

        case 0: //potomny czyta z potoku
            close(filedes[1]);
            int desK = open("./towar", O_CREAT | O_WRONLY | O_TRUNC, 0644);

            sleep(2);
            while(read(filedes[0], &buf, 1) > 0) //czyta z pipe do bufora
            {
                sleep(1);
                printf("odebrano towar: %c\n", buf);
                write(desK, &buf, 1); //zapisuje z bifora do pliku o deskryptorze desK
            }

            close(filedes[0]);
            _exit(EXIT_SUCCESS);
        break;

        default: //macierzysty wpisuje do potoku
            close(filedes[0]);
            int desS = open("./surowce", O_RDONLY);
            char surowiec;
            while(read(desS, &surowiec, 1) > 0) //pobiera surowiec z piku o desktyptorze desS
            {
                sleep(2);
                printf("pobrano surowiec: %c\n", surowiec);
                write(filedes[1], &surowiec, 1); //zapisuje surowiec do pipe
            }
            
            close(filedes[1]);
            wait(NULL);
            exit(EXIT_SUCCESS);
        break;
    }
}