#include <stdio.h>
#include <errno.h>
#include "potoki.h"

int main()
{
    if(mkfifo("/tmp/pipe", 0644)==-1)
    {
        if(errno != EEXIST)
        {    
            perror("FIFO error");
            exit(EXIT_FAILURE);
        }
    }

    switch(fork())
    {
        case -1:
            perror("Fork error");
            exit(EXIT_FAILURE);
        break;

        case 0: //potomny czyta z potoku
            ;
            int desK = open("./towar", O_CREAT | O_WRONLY | O_TRUNC, 0644);
            char buf;
            int pipe1 = open("/tmp/pipe", O_RDONLY);
            sleep(2);
            while(read(pipe1, &buf, 1) > 0) //czyta z pipe do bufora
            {
                sleep(1);
                printf("odebrano towar: %c\n", buf);
                write(desK, &buf, 1); //zapisuje z bifora do pliku o deskryptorze desK
            }
            close(pipe1);
            _exit(EXIT_SUCCESS);
        break;

        default: //macierzysty wpisuje do potoku
            ;
            int desS = open("./surowce", O_RDONLY);
            char surowiec;
            int pipe2 = open("/tmp/pipe", O_WRONLY);
            while(read(desS, &surowiec, 1) > 0) //pobiera surowiec z piku o desktyptorze desS
            {
                sleep(2);
                printf("pobrano surowiec: %c\n", surowiec);
                write(pipe2, &surowiec, 1); //zapisuje surowiec do pipe
            }
            close(pipe2);
            wait(NULL);
            exit(EXIT_SUCCESS);
        break;
    }
}