#include <stdio.h>
#include "potoki.h"

int main()
{
    int desS = open("./surowce", O_RDONLY);
    char surowiec;
    int pipe2 = open("/tmp/pipe", O_WRONLY);
    while(read(desS, &surowiec, 1) > 0) //pobiera surowiec z piku o desktyptorze desS
    {
        sleep(1);
        printf("pobrano surowiec: %c\n", surowiec);
        write(pipe2, &surowiec, 1); //zapisuje surowiec do pipe
    }
    close(pipe2);
    exit(EXIT_SUCCESS);
}