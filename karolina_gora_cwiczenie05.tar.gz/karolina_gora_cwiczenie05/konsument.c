#include <stdio.h>
#include "potoki.h"

int main()
{
    int desK = open("./towar", O_CREAT | O_WRONLY | O_TRUNC, 0644);
    char buf;
    int pipe1 = open("/tmp/pipe", O_RDONLY);
    //sleep(1);
    while(read(pipe1, &buf, 1) > 0) //czyta z pipe do bufora
    {
        sleep(1);
        printf("odebrano towar: %c\n", buf);
        write(desK, &buf, 1); //zapisuje z bifora do pliku o deskryptorze desK
    }
    close(pipe1);
    _exit(EXIT_SUCCESS);
}