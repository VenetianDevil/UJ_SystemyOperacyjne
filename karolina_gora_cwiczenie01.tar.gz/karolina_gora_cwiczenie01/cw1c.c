#include <stdio.h>
#include "cw1.h"

int main()
{
    int i=0;
    for(i=0; i<3; i++)
    {
        switch(fork())
        {
            case -1:
                perror("fork error\n");
                exit(1);
            break;
            case 0:
                sleep(1);
                printf("Proces potomny:\n");
                printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n", getuid(), getgid(), getpid(), getppid(), getpgid());
            break;
            default:
                //printf("Proces macierzysty:\n");
                //printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n", getuid(), getgid(), getpid(), getppid(), getpgid());
            break;
        }
    }
}