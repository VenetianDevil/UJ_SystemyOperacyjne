#include <stdio.h>
#include "cw1.h"

int main()
{
    printf("\nProces MACIERZSTY:\n");
    printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n\n", getuid(), getgid(), getpid(), getppid(), getpgid());

    int i=0;
    for(i=0; i<3; i++)
    {
        switch(fork())
        {
            case -1: //error
                perror("fork error\n");
                exit(1);
            break;
            case 0: // prosces potomny
                printf("Proces potomny %d:\n", i+1);
                printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n", getuid(), getgid(), getpid(), getppid(), getpgid());
            break;
            default: // proces macierzysty
                wait(0);
            //    printf("Proces macierzysty:\n");
            //    printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n", getuid(), getgid(), getpid(), getppid(), getpgid());
            break;
        }
    }
}