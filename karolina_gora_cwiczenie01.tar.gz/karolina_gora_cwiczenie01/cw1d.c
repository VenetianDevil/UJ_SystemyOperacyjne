#include <stdio.h>
#include "cw1.h"

int main()
{
    printf("\nPROCES MACIERZYSTY:\n");
    printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n\n", getuid(), getgid(), getpid(), getppid(), getpgid());

    int i=0;
    for(i=0; i<3; i++)
    {
        switch(fork())
        {
            case -1:
                perror("fork error\n");
                exit(1);
            break;
            case 0:
                printf("Proces potomny:\n");
                printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n", getuid(), getgid(), getpid(), getppid(), getpgid());
                sleep(4-i);
            break;
            default:
                sleep(i+1);
                if(i==2)
                {
                    sleep(2);
                }
                //sleep(i+2);
                //printf("Proces macierzysty:\n");
                //printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n", getuid(), getgid(), getpid(), getppid(), getpgid());
            break;
        }

       // sleep(5);
    }
}