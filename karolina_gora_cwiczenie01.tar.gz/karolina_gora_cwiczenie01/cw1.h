#ifndef PROG1
#define PROG1

#include <sys/types.h>
#include <stdlib.h>

uid_t getuid(); // real user ID
gid_t getgid(); // real group ID
pid_t getpid(); // process ID
pid_t getppid(); // process ID of the parent of the calling process
pid_t getpgid(); // process group on success; error = -1 -->errno is set appropriately
pid_t fork(); // create a new proces; -1 = error; 0 = child; process-ID = the child in the parent
pid_t wait(); // waits for the first child to die; return: wait(2)
unsigned sleep(unsigned sec); //delay for a specified amount of time

#endif