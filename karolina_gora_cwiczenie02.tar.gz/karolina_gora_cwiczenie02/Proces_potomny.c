#include <stdio.h>
#include "cw2.h"

void identyfikatory ()
{
    printf("Proces Potomny:\n");
    printf("UID = %d; GID = %d; PID = %d; PPID = %d; PGID = %d\n\n", getuid(), getgid(), getpid(), getppid(), getpgid(0));
}

int main()
{
    identyfikatory();
    return 0;
}